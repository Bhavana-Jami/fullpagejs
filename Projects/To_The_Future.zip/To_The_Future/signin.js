
// var username="bhavana"
// var password="bhavana"

function login(){
    // var user=document.getElementById("user").value;
    // var pwd=document.getElementById("pwd").value;
    // if(username==user && password==pwd){
    //     window.location="write_a_letter.html";
    // }
    window.location="write_a_letter.html";
    // else{
    //     alert("Enter correct details !");
    // }
    
}
function register(){
    window.location="register.html";
}
function forget(){
    window.location="forgot.html";
}



