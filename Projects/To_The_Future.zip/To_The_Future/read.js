document.querySelector("#element1").innerHTML = localStorage.getItem('yourr_letter');
function logout(){
    window.location="index.html";
}