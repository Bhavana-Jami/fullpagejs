function submit(){
    alert("Check your mail !"); 
}
function login(){
    window.location="index.html";
}